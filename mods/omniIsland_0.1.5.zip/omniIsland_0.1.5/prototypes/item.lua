--item.lua
data:extend{


{
	type = "item",
	name = "omni-scrap",
	icon = "__omniIsland__/graphics/icons/item-omni-scrap.png",
	icon_size = 32,
	    fuel_value = "3MJ",
    fuel_category = "chemical",
	flags = {},
	subgroup = "omni-basic",
	order = "a[base]",
	stack_size = 200,
}
}