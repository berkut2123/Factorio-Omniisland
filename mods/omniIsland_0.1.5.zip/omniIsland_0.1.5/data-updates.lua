data.raw.recipe['landfill'].ingredients = {{"stone", 11}}
data.raw.recipe['landfill'].results = {{type="item", name="landfill", amount=1}}
data.raw.item['landfill'].stack_size = 5000
data.raw.item['omni-scrap'].stack_size = 2000
