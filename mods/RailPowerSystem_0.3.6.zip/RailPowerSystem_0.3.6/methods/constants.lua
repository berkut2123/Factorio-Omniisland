--General
ModName = "RailPowerSystem"

--train
hybridTrain="hybrid-train"

--circuit's components
prototypeConnector="prototype-connector"
railPoleConnector="rail-pole-connector"
circuitNode="electric-node"
railElectricAccu="rail-accu"

--rail
electricRail="electric-rail"
electricStraightRail="straight-rail-power"
electricCurvedRail="curved-rail-power"