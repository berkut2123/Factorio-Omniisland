
if LSlib then
  if not LSlib.utils then LSlib.utils = {}

    require "utils-table"
    require "utils-log"
    require "utils-string"
    require "utils-directions"

  end
end
