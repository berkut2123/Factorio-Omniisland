
if LSlib then
  if not LSlib.entity then LSlib.entity = {}

    require "entity-properties"
    require "entity-icons"
    require "entity-sprites"

  end
end
