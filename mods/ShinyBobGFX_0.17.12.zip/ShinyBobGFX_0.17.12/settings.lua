data:extend(
    {
        {
            type = "bool-setting",
            name = "replace-circuits",
            setting_type = "startup",
            default_value = true,
        },
        {
            type = "bool-setting",
            name = "replace-assemblycolors",
            setting_type = "startup",
            default_value = true,
        },
        {
            type = "bool-setting",
            name = "add-powerbars",
            setting_type = "startup",
            default_value = true,
        },
        {
            type = "bool-setting",
            name = "new-furnaces",
            setting_type = "startup",
            default_value = true,
        },
		{
            type = "bool-setting",
            name = "combat-icons",
            setting_type = "startup",
            default_value = true,
        },
		{
            type = "bool-setting",
            name = "fancy-inserters",
            setting_type = "startup",
            default_value = true,
        }
    }
)
