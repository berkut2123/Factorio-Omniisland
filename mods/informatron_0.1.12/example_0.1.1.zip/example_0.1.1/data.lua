-- style_name, filename, width, height -- style_name MUST be a completely unique name
informatron_make_image("example_image_1", "__example__/example_image.png", 200, 128) 
