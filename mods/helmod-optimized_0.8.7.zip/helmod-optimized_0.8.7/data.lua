require("core.defines")
require("prototypes.fonts")
require("prototypes.style")
require("prototypes.hotkey")
require("prototypes.sprites")

--log(serpent.block(data.raw["gui-style"]))