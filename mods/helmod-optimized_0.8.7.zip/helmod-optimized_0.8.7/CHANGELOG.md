# Changelog
All notable changes to this project will be documented in this file.

## [0.8.7] - 2018-03-17
- added changelog.txt
---------------------------------------------------------------------------------------------------
## [0.8.6] - 2018-03-17
- tried to fix the desynchronization in multiplayer
---------------------------------------------------------------------------------------------------
## [0.8.5] - 2018-03-16
- Optimized graphics, mod size now 0.5 MB vs 1.2MB original
- thanks for this drd_avel
---------------------------------------------------------------------------------------------------
## [0.8.4] - 2018-03-16
- fix bugs
---------------------------------------------------------------------------------------------------
## [0.8.3] - 2018-03-16
- remove fluids without recipe like steam from boiler
- remove logs