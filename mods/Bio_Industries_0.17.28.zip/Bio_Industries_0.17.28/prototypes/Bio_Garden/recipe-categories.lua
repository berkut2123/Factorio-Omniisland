data:extend(
{

	-- Bio Garden
	{
    type = "recipe-category",
    name = "clean-air"
	}
}
)