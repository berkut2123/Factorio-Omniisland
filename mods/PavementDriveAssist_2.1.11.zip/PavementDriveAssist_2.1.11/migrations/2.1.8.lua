--require("__PavementDriveAssist__.config");
global.scores = config.get_scores()