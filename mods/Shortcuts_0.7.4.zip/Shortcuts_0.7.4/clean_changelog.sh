sed -i -e 's/\t/    /g' -e 's/\s*$//' changelog.txt
#from factorioforums: https://forums.factorio.com/viewtopic.php?f=25&t=67140