local handler = require("event_handler")
local modloader = require("__simhelper__/modloader.lua")
handler.add_lib(modloader.load("power-combinator"))
