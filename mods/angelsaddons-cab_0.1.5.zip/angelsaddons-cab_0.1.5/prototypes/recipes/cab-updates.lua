angelsmods.functions.RB.build({
  {
    type = "recipe",
    name = "angels-cab",
    energy_required = 10,
    enabled = "false",
    ingredients =
    {
      {"motor-3", 5},
      {"mechanical-parts", 10},
      {"construction-frame-3", 5},
      {"construction-components", 20},
      {"circuit-orange-loaded", 2},
      mods["angelsindustries"] and {"angels-crawler", 1} or nil,
    },
    result = "angels-cab"
  },
}
)
