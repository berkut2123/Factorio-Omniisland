--[[--
Control script where all code is executed.
@script control
]]
-- Mod = require("lib/Import")
protoNames = require "prototypes/names"
require "lib/util"
-- inform = util.inform
-- isValid = util.isValid
require "lib/gSettings"
-- gSettings = gSets
require "lib/Initializer"
require "lib/Version"

require "lib/Queue"
require "lib/PriorityQueue"
require "lib/Array"
-- List = Array
require("lib/Map")
require "lib/ModCompat"

require "lib/createdQ"
require "lib/DB"
require "lib/ItemDB"
-- ItemDB.item
require "lib/Force"
-- FRC = Force
require "lib/TrackedSlot"
require "lib/TrackedChest"
require "lib/HiddenInserter"
require "lib/idQ"

require "lib/Rem"

require "stdlib/area/area"
require "stdlib/string"
require "stdlib/table"
require "stdlib/area/position"

require "lib/Handlers"

function errorStack()
    inform("errorStack:\n" .. debug.traceback(), true)
end

Init.registerFunc(
    --_init
    function()
        global["trackedPlayers"] = {}
        local tp = global["trackedPlayers"]
        for pInd, player in pairs(game.players) do
            if (player.surface.name == "nauvis") then
                tp[pInd] = player.position
            end
        end
    end
)
function trackedPlayers()
    return global["trackedPlayers"]
end
function trackedPos(playerInd)
    return trackedPlayers()[playerInd]
end
