--[[--
TrackedChest: Class representing a single loader chest.
@classmod TC
@alias TrackedChest
]]
TC = {}
TC.className = "TrackedChest"
TC.dbName = TC.className
DB.register(TC.dbName)
TC.rangeIndicator = "ammo-loader-range-indicator"
--[[--
Metatable
@table objMT
]]
TC.objMT = {
    __index = TC
}

function TC._init()
    util.destroyAll({name = TC.rangeIndicator})
    -- util.destroyAll(TC.indicators.infinite)
    -- DB.new(TC.dbName)
    global["TC"] = {}
    global["TC"]["chestNames"] = TC.findChestNames()
    global["TC"]["indicators"] = {count = 0, queue = Q.new()}
end
Init.registerFunc(TC._init)
function TC._onLoad()
    for id, obj in pairs(DB.getAll(TC.dbName)) do
        setmetatable(obj, TC.objMT)
        -- setmetatable(obj._slotsInRangeQ, idQ.objMT)

        for item, qList in pairs(obj._addCache) do
            if (qList.orphanQ) then
                setmetatable(qList.orphanQ, idQ.objMT)
            end
            if (qList.upgradeQ) then
                setmetatable(qList.upgradeQ, idQ.objMT)
            end
        end
    end
end
Init.registerOnLoadFunc(TC._onLoad)

function TC.dbInsert(chest)
    return DB.insert(TC.dbName, chest)
end

function TC.master()
    return global["TC"]
end
function TC.chestNames(listType)
    if not listType then
        return TC.master()["chestNames"]
    end
    return TC.master()["chestNames"][listType]
end
function TC.chestDB()
    return DB.getAll(TC.dbName)
end

function TC.indicators()
    return global["TC"]["indicators"]
end

function TC.isTrackable(ent)
    if (not ent) or (not ent.valid) or (not TC.isChest(ent)) or (TC.getChestFromEnt(ent)) then
        return false
    end
    return true
end

--- Create new TrackedChest object
-- @param ent Entity to use to create new chest.
-- @return Tracked Chest object
function TC.new(ent)
    if (not TC.isTrackable(ent)) then
        cInform("TC.new: entity not valid chest")
        return nil
    end

    local obj = {}
    setmetatable(obj, TC.objMT)
    obj.entName = ent.name
    obj.ent = ent
    obj._forceName = ent.force.name
    obj._surfaceName = ent.surface.name
    obj.inv = ent.get_inventory(defines.inventory.chest)
    if not isValid(obj.inv) then
        return nil
    end
    local pos = ent.position
    obj._posX = pos.x
    obj._posY = pos.y
    obj.id = TC.dbInsert(obj)

    local rad = gSets.chestRadius()
    local force = Force.get(ent.force.name)
    obj.consumers = {}
    if (rad > 0) then
        obj.area = Position.expand_to_area(obj:position(), rad)
    end
    if (ent.name == protoNames.chests.storage) then
        obj.isStorage = true
    end
    obj._cacheLastTick = 0
    obj._invCache = {}
    obj._removalCache = {}
    obj._addCache = {}
    obj._indicators = {count = 0, ents = {}}
    if (obj.isStorage) and (force.storageChests:size() <= 0) then
        local slots = force.slots
        cInform("slots in force: ", slots:size())
        for s in slots:iter() do
            force:addOrphan(s)
        end
    end
    force:addChest(obj)
    cInform("created new chest")
    return obj
end

function TC.isInRange(self, slot)
    return util.isInRange(slot, self)
end

TC.position = function(self)
    return {x = self._posX, y = self._posY}
end

TC.surface = function(self)
    return self.ent.surface
end
TC.surfaceName = function(self)
    return self._surfaceName
end

function TC.destroy(self)
    local force = self:force()
    for catName, cat in pairs(force.provs.categories) do
        for itemName, item in pairs(cat.items) do
            local cons = item.ids[self.id]
            item.ids[self.id] = nil
            item.count = item.count - 1
            if (cons) then
                for id, t in pairs(cons) do
                    local slot = SL.getObj(id)
                    if (slot) then
                        slot:setProv()
                        slot:queueAllProvs()
                    end
                end
            end
        end
    end
    DB.deleteID(TC.dbName, self.id)
end

function TC.isValid(self)
    if not self then
        return false
    end
    if (not self.ent) or (not self.ent.valid) then
        return false
    end
    return true
end

function TC.drawRange(self, player)
    local radius = gSets.chestRadius()
    if (radius <= 0) or (radius > 100) then
        return
    end
    -- local alpha = 0.1
    -- local color = {r = 0.02, g = 0.05, b = 0.12, a = alpha}
    local opts = {
        -- color = util.colors.fuchsia,
        color = util.colors.litePurple,
        -- radius = radius,
        filled = true,
        left_top = self.area.left_top,
        right_bottom = self.area.right_bottom,
        surface = self:surface().name,
        players = {player.index},
        draw_on_ground = false
    }
    -- rendering.draw_circle(opts)
    rendering.draw_rectangle(opts)
end

function TC.highlightConsumers(self, player)
    local slots = self:consumerQ()
    local ents = {}
    for slot in slots:iter() do
        slot:drawLineToProvider(player)
        if (not Array.contains(slot.ent)) then
            slot:highlight(player)
            Array.insert(ents, slot.ent)
        end
    end
end

function TC.entDrawRange(ent)
    local chest = TC.getObjFromEnt(ent)
    if not chest then
        return nil
    end
    chest:drawRange()
end

function TC.force(self)
    -- return Force.get(self.ent.force.name)
    return Force.get(self:forceName())
end
function TC.forceName(self)
    -- return self.ent.force.name
    return self._forceName
end

function TC.itemAmt(self, item, new)
    if (new) then
        self._invCache[item] = new
        return new
    end
    local amt = self._invCache[item] or 0
    return amt
end

function TC.allChests()
    local q = idQ.new(TC.dbName)
    for id, chest in pairs(DB.getEntries(TC.dbName)) do
        idQ.push(q, chest)
    end
    return q
end
function TC.findChestNames()
    local result = {list = {}, hash = {}}
    local hash = result.hash
    local list = result.list
    for key, name in pairs(protoNames.chests) do
        hash[name] = true
        list[#list + 1] = name
    end
    return result
end

function TC.isChest(ent)
    if (not ent) then
        return false
    end
    if (Map.containsValue(protoNames.chests, ent.name)) then
        return true
    end
    return false
end

function TC.getObj(id)
    return DB.getObj(TC.dbName, id)
end

function TC.highestID()
    return DB.get(TC.dbName).nextID - 1
end

function TC.getObjFromEnt(ent)
    for id, obj in pairs(DB.getAll(TC.dbName)) do
        if (obj.ent == ent) then
            return obj
        end
    end
    return nil
end
TC.getChestFromEnt = TC.getObjFromEnt

function TC.insert(self, stack)
    if (not stack) or (stack.count <= 0) then
        return 0
    end
    local amtInserted = self.inv.insert(stack)
    local cache = self._invCache
    local item = stack.name
    if (amtInserted > 0) then
        if not cache[item] then
            cache[item] = amtInserted
        else
            cache[item] = cache[item] + amtInserted
        end
    end
    return amtInserted
end
TC.insertStack = TC.insert

function TC.remove(self, stack)
    local cache = self._invCache
    if (not stack) or (stack.count <= 0) then --or (not cache[stack.name]) or (cache[stack.name] <= 0) then
        return 0
    end
    local amtRemoved = self.inv.remove(stack)
    local item = stack.name

    if (cache[item]) then
        cache[item] = cache[item] - amtRemoved
    end
    return amtRemoved
end

function TC.slotsInRangeQ(self)
    if (not self.area) then
        return self:force().slots
    else
        return self._slotsInRangeQ
    end
end

function TC.hasCat(self, cat)
    for item, count in pairs(self._invCache) do
        local inf = itemInfo(item)
        if (inf.category == cat) then
            return true
        end
    end
    return false
end

function TC.providedItems(self)
    local force = self:force()
    local items = {}
    for catName, cat in pairs(force.provs.categories) do
        for itemName, item in pairs(cat.items) do
            local cons = item.ids[self.id]
            if (cons) then
                items[itemName] = cons
            end
        end
    end
    return items
end

function TC.isProvidingCat(self, catName)
    local cat = self:force().provs.categories[catName]
    for itemName, item in pairs(cat.items) do
        local cons = item.ids[self.id]
        if (cons) then
            return true
        end
    end
    return false
end

function TC.catItems(self, catName)
    local cat = self:force().provs.categories[catName]
    local items = {}
    for itemName, item in pairs(cat.items) do
        local cons = item.ids[self.id]
        if (cons) then
            Array.insert(items, itemName)
        end
    end
    return items
end

function TC.consumerQ(self)
    local items = self:providedItems()
    local q = idQ.new(SL, true)
    for itemName, ids in pairs(items) do
        for id, t in pairs(ids) do
            local obj = SL.getObj(id)
            if (obj) then
                local sourceID = obj:sourceID()
                if sourceID and sourceID == self.id then
                    q:push(obj)
                end
            end
        end
    end
    return q
end

function TC.itemConsumers(self, item)
    -- local inf = itemInfo(item)
    local f = self:force()
    local provItem = f:provItem(item)
    local reg = provItem.ids[self.id]
    return reg
end

function TC.itemConsumerQ(self, item)
    local cons = self:itemConsumers(item)
    local q = idQ.new(SL)
    if cons then
        for id, t in pairs(cons) do
            local obj = SL.getObj(id)
            if (obj) then
                q:push(id)
            end
        end
    end
    return q
end

function TC.doQ(self)
    local force = self:force()
    local maxSlots = gSets.maxSlotsPerChestTick()
    local addCache = self._addCache

    for item, qList in pairs(addCache) do
        if force.slotsChecked >= maxSlots then
            break
        end
        local itemCount = self:itemAmt(item)

        if (itemCount > 0) then
            local inf = itemInfo(item)
            local orphQ = qList.orphanQ
            local upQ = qList.upgradeQ
            local numSet = 0
            if (orphQ:size() > 0) then
                local qSize = orphQ:size()
                cInform("processing orphQ for ", item, " -- ", qSize, " entries remaining")
                local n = 0
                while (n < qSize) and (itemCount > 0) and (force.slotsChecked < maxSlots) do
                    n = n + 1
                    local slot = orphQ:pop()
                    if not slot then
                        break
                    end
                    local curFilter = slot:filterItem()
                    if (curFilter) then
                        inform("not orphan, moving to upgrade queue.")
                        upQ:push(slot)
                    else
                        if (not slot.canMove) or (self:isInRange(slot)) then
                            numSet = numSet + 1
                            slot:setProv(self, item)
                            itemCount = self:itemAmt(item)
                        end
                    end
                end
            elseif (upQ:size() > 0) then
                local qSize = upQ:size()
                cInform("processing upQ for ", item, " -- ", qSize, " entries remaining")
                local n = 0
                while (n < qSize) and (itemCount >= inf.fillLimit) and (force.slotsChecked < maxSlots) do
                    n = n + 1
                    local slot = upQ:pop()
                    if not slot then
                        break
                    end
                    local curItemInf = slot:filterInfo()
                    if (not curItemInf) or (curItemInf.rank > inf.rank) then
                        if (not slot.canMove) or (self:isInRange(slot)) then
                            numSet = numSet + 1
                            slot:setProv(self, item)
                            itemCount = self:itemAmt(item)
                        end
                    end
                end
                cInform("set ", numSet, " slots to ", item)
            end
        else
            cInform("itemcount for ", item, " <= 0!")
        end
    end
end

function TC.updateCache(self)
    local gTick = gSets.tick()
    local ticksToWait = gSets.ticksBeforeCacheRemoval()
    local fTick = gTick + ticksToWait
    local newCache = self.inv.get_contents()
    local oldCache = self._invCache
    self._invCache = newCache
    local force = self:force()
    local rmCache = self._removalCache
    local addCache = self._addCache
    for item, count in pairs(self._invCache) do
        local inf = ItemDB.item.get(item)
        if (inf) then
            rmCache[item] = nil
            if (not oldCache[item]) and (not addCache[item]) then
                force:addProv(self, item)
                local orphQ = idQ.new(SL, true)
                local upQ = idQ.new(SL, true)
                addCache[item] = {orphanQ = orphQ, upgradeQ = upQ}
                -- local orphs = force:provCat(inf.category).orphans
                -- for slotID, t in pairs(orphs) do
                --     local slot = SL.getObj(slotID)
                --     if (not slot) then
                --         orphs[slotID] = nil
                --     elseif (self:isInRange(slot)) then
                --         orphQ:push(slot)
                --     end
                -- end
                local orphs = force:orphansInCatQ(inf.category)
                for slot in orphs:iter() do
                    if (self:isInRange(slot)) then
                        orphQ:push(slot)
                    end
                end
                local dbItems = ItemDB.cat(inf.category).items
                for i = inf.rank + 1, #dbItems do
                    local provItm = force:provItem(dbItems[i])
                    for chestID, cons in pairs(provItm.ids) do
                        for slotID, t in pairs(cons) do
                            local slot = SL.getObj(slotID)
                            if (slot) then
                                if (self:isInRange(slot)) then
                                    upQ:push(slot)
                                end
                            else
                                cons[slotID] = nil
                            end
                        end
                    end
                end
            end
        end
    end
    for item, count in pairs(oldCache) do
        local inf = itemInfo(item)
        if (inf) and (not self._invCache[item]) and (not rmCache[item]) then
            rmCache[item] = fTick
        end
    end
    for item, tick in pairs(rmCache) do
        if (gTick >= tick) then
            rmCache[item] = nil
            addCache[item] = nil
            force:removeProv(self, item)
        end
    end
end

function TC.tick(self)
    if not self then
        inform("null chest sent to TC.tick")
        return
    end
    if (self.isStorage) then
        return
    end
    local gTick = gSets.tick()
    local minTicks = gSets.ticksBetweenChestCache()
    if (gTick >= self._cacheLastTick + minTicks) then
        self._cacheLastTick = gTick
        self:updateCache()
    end
    self:doQ()
end
return TC
