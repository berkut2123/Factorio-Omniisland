Handlers = {}

function Handlers.enabled()
    if (gSets.enabled()) and (not version.needUpdate()) then
        return true
    end
    return false
end

function Handlers.onEvents(func, eventNames)
    -- local hand = handler(func)
    for i = 1, #eventNames do
        local name = eventNames[i]
        local event = defines.events[name]
        if not event then
            event = name
        end
        script.on_event(event, func)
    end
end
local onEvents = Handlers.onEvents

function Handlers.onBuilt(event)
    if not Handlers.enabled() then
        return
    end
    cInform("onBuilt")
    local ent = event.created_entity
    if (not ent) or (not ent.valid) then
        ent = event.entity
        if (not ent) or (not ent.valid) then
            return
        end
    end
    local waitEnt = createdQ.waitQTriggers[ent.name]
    if (waitEnt) then
        cInform("adding to waitQ")
        createdQ.waitQAdd(waitEnt)
    end
    cInform("adding to createdQ")
    createdQ.push(ent)
end
onEvents(Handlers.onBuilt, {"on_built_entity", "on_robot_built_entity", "script_raised_built"})
-- script.on_event(defines.events.on_built_entity, on_built)
-- script.on_event(defines.events.on_robot_built_entity, on_built)
-- script.on_event(defines.events.script_raised_built, on_built)
function Handlers.onRemoved(event)
    if not Handlers.enabled() then
        return
    end
    local ent = event.entity
    local forceName = ent.force.name
    if (not ent) or (not ent.valid) or (forceName == "neutral") or (forceName == "enemy") then
        return
    end
    if (TC.isChest(ent)) then
        local chest = TC.getObjFromEnt(ent)
        if (chest) then
            chest:destroy()
        end
        return
    end
    local tracked = SL.trackable.all()
    if tracked[ent.name] then
        local cause = event.cause
        local slotsArr = SL.getSlotsFromEnt(ent)
        local slots = idQ.fromArray(slotsArr, SL, true)
        for slot in slots:iter() do
            if (gSets.doReturn()) and (not cause) then
                slot:returnItems()
            end
            inform("destroy slot")
            slot:destroy()
        end
    end
end
onEvents(Handlers.onRemoved, {"on_pre_player_mined_item", "on_robot_pre_mined", "on_entity_died", "script_raised_destroy"})

-- Handlers.trackPlayer =
-- function(event)
-- local player = game.players[event.player_index]
-- if (game.surfaces[event.surface_index].name ~= "nauvis") then
-- if (player.surface.name == "nauvis") then
-- trackedPlayers()[player.index] = player.position
-- end
-- end
-- end
-- onEvents(trackPlayer, {"on_player_changed_surface"})

function Handlers.settingChange(event) -- handler(
    if gSettings.requireUpdate[event.setting] then
        version.update()
    else
        gSets.update()
    end
end
-- )
script.on_event(defines.events.on_runtime_mod_setting_changed, Handlers.settingChange)
function Handlers.preTick(event)
    gSets.tick(event.tick)
    -- if (gSets.tick() == event.tick) then
    -- return false
    -- end
    if version.needUpdate() then
        version.update()
        return false
    end
    if (not gSets.enabled()) then
        return false
    end
    return true
end
function Handlers.onNthTick(event)
    if not Handlers.preTick(event) then
        return
    end
    -- local prof = game.create_profiler()
    Force.tickAll()
    -- prof.stop()
    -- cInform("Profiler Force.tickAll: ", prof)
    -- util.printProfiler()
    -- game.print(prof)
end
function Handlers.onEveryTick(event)
    if not Handlers.preTick(event) then
        return
    end
    -- local prof = game.create_profiler()
    createdQ.tick()
    -- prof.stop()
    -- cInform("createdQ.tick: ")
    -- util.printProfiler()
end
function Handlers.updateRenders(event)
    if not Handlers.preTick(event) then
        return
    end
    -- local prof = game.create_profiler()
    if (global.draw_toggle.count > 0) then
        for pIndex, t in pairs(global.draw_toggle) do
            if (pIndex ~= "count") then
                Handlers.keyChestRangeToggle({player_index = pIndex})
                Handlers.keyChestRangeToggle({player_index = pIndex})
            end
        end
    end
    -- prof.stop()
    -- cInform("updateRenders: ")
    -- util.printProfiler()
end
-- script.on_event(defines.events.on_tick, on_tick)
-- script.on_nth_tick(settings.global["ammo_loader_ticks_between_cycles"].value, on_tick)
script.on_nth_tick(gSets.ticksBetweenCycles(), Handlers.onNthTick)
script.on_nth_tick(30, Handlers.updateRenders)
onEvents(Handlers.onEveryTick, {"on_tick"})
script.on_configuration_changed(version.update)
script.on_init(Init.doInit)

function Handlers.onLoad()
    if not version.needUpdate() then
        Init.doOnLoad()
    end
end
script.on_load(Handlers.onLoad)

function Handlers.onSelectedEntity(event)
    if not Handlers.enabled() then
        return
    end
    local player = game.players[event.player_index]
    if (not player) or (not gSets.drawRange(player)) or (gSets.drawToggle(player)) then
        return
    end
    util.clearPlayerRenders(player)
    local selected = player.selected
    if (not selected) or (not selected.valid) or (selected.force.name ~= player.force.name) then
        return
    end
    if (TC.isChest(selected)) then
        local chest = TC.getObjFromEnt(selected)
        if (chest) then
            chest:drawRange(player)
            chest:highlightConsumers(player)
        end
    elseif (SL.isTrackedName(selected.name)) then
        local slots = SL.getSlotsFromEnt(selected, true)
        for slot in slots:iter() do
            local prov = slot:provider()
            local slotColor = util.colors.red
            if (prov) then
                slotColor = util.colors.blue
                slot:drawLineToProvider(player)
            end
            slot:highlight(player, slotColor)
        end
    end
end
onEvents(Handlers.onSelectedEntity, {"on_selected_entity_changed"})

function Handlers.onResearch(event)
    if not Handlers.enabled() then
        return
    end
    local tech = event.research
    if (Map.containsValue(protoNames.tech, tech.name)) then
        -- Force.get(tech.force.name).techs[tech.name] = true
        version.update()
    elseif (gSets.checkAfterResearch()) then
        local fName = event.research.force.name
        local force = Force.get(fName)
        force.needPurge = true
    end
end
onEvents(Handlers.onResearch, {"on_research_finished"})

function Handlers.keyReturn(event)
    inform("returning all items.")
    -- SL.returnAll(true, false)
    local player = game.players[event.player_index]
    if (player) then
        SL.clearAllSlots(player.force.name)
    end
    -- inform(event)
    -- for id, slotObj in pairs(SL.allSlots()) do
    --     slotObj:returnItems(true)
    -- end
end
onEvents(Handlers.keyReturn, {"ammo-loader-key-return"})

function Handlers.keyReset()
    version.update()
end
onEvents(Handlers.keyReset, {"ammo-loader-key-reset"})

function Handlers.keyToggleEnabled()
    local isEnabled = gSets.enabled()
    if isEnabled then
        settings.global["ammo_loader_enabled"] = {value = false}
        version.update()
        ctInform("Ammo Loader Mod disabled")
    else
        settings.global["ammo_loader_enabled"] = {value = true}
        version.update()
        ctInform("Ammo Loader Mod enabled")
    end
end
onEvents(Handlers.keyToggleEnabled, {"ammo-loader-key-toggle-enabled"})

function Handlers.keyChestRangeToggle(event)
    local pInd = event.player_index
    local player = game.players[pInd]
    if (not player) then
        return nil
    end
    util.clearPlayerRenders(player)
    local isOn = gSets.drawToggle(player)
    if (isOn) then
        gSets.drawToggle(player, false)
        return
    end
    local chests = Force.get(player.force.name).chests
    for chest in chests:iter() do
        chest:drawRange(player)
        chest:highlightConsumers(player)
    end
    gSets.drawToggle(player, true)
end
onEvents(Handlers.keyChestRangeToggle, {"ammo-loader-key-toggle-chest-ranges"})

-- script.on_event("ammo-loader-key-return", keyReturn)
-- function keyUpgrade(event)
-- 	for name, frc in pairs(FRC.forces()) do
-- 		local slots = frc.slots
-- 		for i=1, slots:size() do
-- 			local slotObj = slots:cycle()
-- 			if not slotObj then break end
-- 			slotObj.doUpgrade = true
-- 		end
-- 	end
-- 	inform("upgrading all inventories to best available items.", true)
-- end
-- script.on_event("ammo-loader-key-upgrade", keyUpgrade)
-- keyChestGUI =
--     handler(
--     function(event)
--         local player = game.players[event.player_index]
--         if (not player) then
--             return nil
--         end
--         local entity = player.selected
--         if not (entity) then
--             return
--         end
--         local proto = entity.prototype
--         local params = proto.attack_parameters
--         if (params) then
--             inform(util.table.tostring(params))
--         end
--         -- local slotObj = SL.getSlotsByEnt(entity)[1]
--         -- if (not slotObj) then
--         --     return
--         -- end
--         -- player.opened = slotObj:inserter().ent
--     end
-- )
-- script.on_event("ammo-loader-key-chest-filter-GUI", keyChestGUI)
-- keyChestRangeToggle =
--     handler(
--     function(event)
--         local pInd = event.player_index
--         local player = game.players[pInd]
--         if (not player) then
--             return nil
--         end
--         local fName = player.force.name
--         local inds = TC.indicators()
--         if (inds.toggled) then
--             TC.clearAllIndicators(fName)
--             inds.toggled = nil
--         else
--             TC.queueAllIndicators(fName)
--             inds.toggled = true
--         end
--     end
-- )
