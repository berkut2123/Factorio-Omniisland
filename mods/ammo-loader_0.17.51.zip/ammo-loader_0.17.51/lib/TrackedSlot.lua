--[[--
TrackedSlot: Class representing a single tracked slot.
@classmod SL
]]
SL = {}
SL.className = "TrackedSlot"
SL.dbName = SL.className
DB.register(SL.dbName)

--[[-- Metatable for all instances to use.
@table objMT
]]
SL.objMT = {
    __index = SL
}
-- local TS = SL
function SL._onLoad()
    for id, obj in pairs(DB.getAll(SL.dbName)) do
        setmetatable(obj, SL.objMT)
    end
end
Init.registerOnLoadFunc(SL._onLoad)

SL._trackableTypes = {
    "artillery-turret",
    "ammo-turret",
    "artillery-wagon",
    "locomotive",
    "car"
}
SL.invTypes = {
    defines.inventory.turret_ammo,
    defines.inventory.car_ammo
}
SL.ammoEntTypes = {
    "artillery-turret",
    "ammo-turret",
    "artillery-wagon",
    "car"
}

function SL.trackableTypes(hash)
    local types = SL._trackableTypes
    if (hash) then
        return Array.toHash(types)
    end
    return Map.copy(types)
end

function SL._init()
    -- HI.destroyAll()
    -- DB.new(SL.dbName)
    global["trackedEntNames"] = {}
    local slotTypes = SL.trackableTypes(true)
    for name, proto in pairs(game.entity_prototypes) do
        if (slotTypes[proto.type]) or (proto.burner_prototype) then
            if (proto.name ~= protoNames.hiddenInserter) and (not Mods.VehicleTurrets.isVehicleTurret(proto)) then
                global["trackedEntNames"][proto.name] = {}
            end
        end
    end
end
Init.registerFunc(SL._init)

function SL.highestID()
    return DB.highest(SL.dbName)
end

function SL.emptyStack()
    return {name = nil, count = 0}
end

SL.trackable = {}

SL.trackable.all = function()
    return global["trackedEntNames"]
end
SL.trackedEnts = SL.trackable.all

function SL.trackable.getOrAddEnt(ent)
    local tracked = SL.trackable.all()
    local tEnt = tracked[ent.name]
    if not tEnt then
        tEnt = {}
        tracked[ent.name] = tEnt
    end
    return tEnt
end
SL.trackable.addEnt = SL.trackable.getOrAddEnt

function SL.trackable.getOrAddInv(ent, ind)
    local invs = SL.trackable.getOrAddEnt(ent)
    local inv = invs[ind]
    if not inv then
        inv = {}
        invs[ind] = inv
    end
    return inv
end
SL.trackable.addInv = SL.trackable.getOrAddInv

function SL.trackable.getOrAddSlot(ent, invInd, slotInd)
    local slots = SL.trackable.getOrAddInv(ent, invInd)
    local slot = slots[slotInd]
    if not slot then
        slot = true
        slots[slotInd] = slot
    end
    return slot
end

function SL.isTrackable(ent)
    if (not isValid(ent)) or (ent.name == protoNames.hiddenInserter) or (not SL.trackedEnts()[ent.name]) or (ent.type == "boiler") or (#SL.getSlotsFromEnt(ent) > 0) then
        return false
    end
    return true
end
SL.isTrackableEnt = SL.isTrackable
SL.trackableEnt = SL.isTrackable

function SL.isTrackedName(ent)
    if (SL.trackedEnts()[ent]) then
        return true
    end
    return false
end

function SL.allSlots()
    return DB.getAll(SL.dbName)
end

function SL.clearAllSlots(forceName)
    local slots = Force.get(forceName).slots
    slots:forEach(SL.returnItems, nil, true)
end

function SL.returnAll(forceEmpty)
    local forces = {}
    local slots = SL.allSlots()
    for id, slotObj in pairs(slots) do
        local spillStack = slotObj:returnItems(forceEmpty, false)
        if (spillStack ~= nil) and (spillStack.count > 0) then
            local fName = slotObj:forceName()
            local force = forces[fName]
            if not force then
                force = {}
                forces[fName] = force
            end
            local spill = force
            local amt = spill[spillStack.name]
            if (not amt) then
                amt = 0
                spill[spillStack.name] = amt
            end
            spill[spillStack.name] = amt + spillStack.count
        end
    end
    for forceName, inv in pairs(forces) do
        for item, amt in pairs(inv) do
            local stack = {name = item, count = amt}
            game.surfaces.nauvis.spill_item_stack({x = 0, y = 0}, stack, true, forceName)
        end
    end
end

function SL.entNeedsProvided(ent)
    if (not ent) then
        return
    end
    if (ent.name:find("meteor")) then
        return true
    end
end

function SL.trackAllSlots(ent)
    if (not SL.isTrackable(ent)) then
        cInform("SL.trackAllSlots: ent not trackable")
        return nil
    end
    -- local f = Force.get(ent.force.name)
    -- local sl = f.slots
    -- local cyc = sl.cycle
    -- for i = 1, sl:size() do
    --     local test = cyc(sl)
    --     if (not test) then
    --         break
    --     end
    --     if (test.ent == ent) then
    --         inform("Slot already exists, aborting create.")
    --         return
    --     end
    -- end
    if (ent.burner) and (#ent.burner.inventory > 0) then
        local slotCat, slotType = SL.getSlotCat(ent.burner.inventory[1])
        SL.new(ent, ent.burner.inventory, 1, slotCat, slotType)
    end
    if (not Array.contains(SL.ammoEntTypes, ent.type)) then
        cInform("SL.trackAll: ent type not ammo type")
        return nil
    end
    local invTypes = SL.invTypes
    local invs = {}
    -- local ammoInvs = {}
    -- local main = ent.get_main_inventory()
    -- if (isValid(main)) then
    --     invs[#invs + 1] = main
    -- end
    for ind, invType in pairs(invTypes) do
        local newInv = ent.get_inventory(invType)
        if (isValid(newInv)) and (#newInv > 0) and (not Array.contains(invs, newInv)) then
            invs[#invs + 1] = newInv
        end
    end
    -- if (#invs > 0) then
    -- cInform("SL.trackAll: found inventory")
    -- else
    -- cInform("SL.trackAll: no invs found")
    -- end

    local _i = 0
    local _s = 0
    local newSlots = {}
    for ind, inv in pairs(invs) do
        _i = _i + 1
        local slotsToCreate = 1
        if (ent.prototype.guns ~= nil) then
            slotsToCreate = #inv
        end
        for i = 1, slotsToCreate do
            _s = _s + 1
            local slotCat, slotType = SL.getSlotCat(inv[i])
            if (slotType) and (slotType == "ammo") then
                local newSlot = SL.new(ent, inv, i, slotCat, slotType)
                if (newSlot) then
                    newSlots[#newSlots + 1] = newSlot
                end
            end
        end
    end
    if (#newSlots > 0) then
        cInform(#newSlots, " new slot(s) created")
        return true
    end
    cInform("no new slots created")
    return false
end

function SL.new(ent, inv, index, slotCat, slotType)
    if (not slotCat) or (not slotType) then
        cInform("SL.new: missing category or type")
        return nil
    end
    local ind = index or 1
    if not SL.isValidSlot(inv, ind) then
        cInform("SL.new: invalid slot")
        return nil
    end
    local obj = {}
    setmetatable(obj, SL.objMT)
    obj.ent = ent
    obj._forceName = ent.force.name
    obj._surfaceName = ent.surface.name
    obj.invInd = SL.getInvInd(ent, inv)
    if (not obj.invInd) then
        obj._inv = inv
    end
    obj.slotInd = ind
    local force = Force.get(obj.ent.force.name)
    if (not gSets.doTrains()) and (ent.type == "locomotive") then
        return nil
    end
    obj.type = slotType
    obj.consumerCat = slotCat
    obj.category = slotCat

    if (obj.consumerCat == "artillery-shell") and (not force:doArtillery()) then
        return nil
    end
    local pos = ent.position
    if (SL.entNeedsProvided(ent)) then
        obj.isProvided = true
    end
    if (SL.entCanMove(ent)) then
        if (not force:doVehicles()) then
            return nil
        end
        obj.isProvided = true
        obj.canMove = true
    elseif (obj.type == "fuel") and (not force:doBurners()) then
        return nil
    end
    if (ent.surface.name ~= "nauvis") then
        if (gSets.rangeIsInfinite()) then
            obj.isProvided = true
        end
    end
    if (not obj.canMove) then
        obj._posX = pos.x
        obj._posY = pos.y
    end
    obj.id = SL.dbInsert(obj)
    if obj.isProvided then
        obj._inserter = {lastTick = 0}
        obj._slot = inv[index]
    else
        obj.inserterID = SL.newInserter(obj).id
    end
    obj.render = {}
    force:addSlot(obj)
    -- force:provCat(obj.consumerCat).orphans[obj.id] = true
    -- obj.isOrphan = true
    -- obj:queueAllProvs(true)
    SL.trackable.getOrAddSlot(ent, obj.invInd, obj.slotInd)
    inform("new slot-> name: " .. obj.ent.name .. ", cat: " .. obj.consumerCat)
    return obj
end

function SL.isInRange(self, chest)
    return util.isInRange(self, chest)
end

SL.getArea = function(self)
    local rad = gSets.chestRadius()
    if rad > 0 then
        return Position.expand_to_area(self:position(), rad)
    end
    return nil
end

SL.surface = function(self)
    return self.ent.surface
end
SL.surfaceName = function(self)
    return self._surfaceName
end

SL.inv = function(self)
    if (not self.invInd) and (self._inv) and (self._inv.valid) then
        return self._inv
    end
    if (self.invInd) and (self.ent) and (self.ent.valid) then
        return self.ent.get_inventory(self.invInd)
    end
    return nil
end
SL.slot = function(self)
    if (not self._slot) then
        local inv = self:inv()
        if (inv) and (inv.valid) and (inv[self.slotInd]) then
            return inv[self.slotInd]
        end
    else
        return self._slot
    end
    return nil
end

function SL.inserter(self)
    if (self.inserterID) then
        return DB.getEntries(HI.dbName)[self.inserterID]
    end
    return self._inserter
end

function SL.getHeldStack(self)
    if (self.inserterID) then
        return self:inserter():heldStack()
    end
    return SL.emptyStack()
end
SL.heldStack = SL.getHeldStack

function SL.clearHeldStack(self)
    if (self.inserterID) then
        return self:inserter():returnHeld()
    end
end
SL.clearHeld = SL.clearHeldStack

function SL.destroy(self)
    self:registerCons()
    if (self.inserterID) then
        local ins = self:inserter()
        if (ins) then
            ins:destroy()
        end
    end
    DB.deleteID(SL.dbName, self.id)
end

function SL.getPosition(self)
    if (self._posX) then
        return {x = self._posX, y = self._posY}
    end
    return self.ent.position
end
SL.position = SL.getPosition

function SL.getForce(self)
    return Force.get(self:forceName())
end
SL.force = SL.getForce
SL.forceName = function(self)
    return self._forceName
end

function SL.getItemInfo(self)
    local stack = self:getItemStack()
    if stack.count > 0 then
        return ItemDB.item.get(stack.name)
    end
    return nil
end
SL.itemInfo = SL.getItemInfo
SL.getCurItemInfo = SL.getItemInfo
SL.stackItemInfo = SL.getItemInfo

function SL.getSourceID(self)
    local ins = self:inserter()
    return ins.sourceID
end
SL.sourceID = SL.getSourceID
SL.provID = SL.getSourceID

--- Return Hidden Inserter's current pickup target.
-- @param self
-- @return Provider
function SL.getCurProvider(self)
    local sourceID = self:sourceID()
    if (not sourceID) then
        return nil
    end
    local chest = TC.getObj(sourceID)
    if not chest then
        self:setProv()
    end
    return chest
end
SL.curProvider = SL.getCurProvider
SL.provider = SL.getCurProvider

function SL.getBestItemInfo(self)
    return itemInfo(self:filterItem())
end
SL.filterInfo = SL.getBestItemInfo
SL.bestItemInfo = SL.getBestItemInfo
SL.provItemInfo = SL.getBestItemInfo

function SL.getFilterScore(self)
    local inf = self:filterInfo()
    if not inf then
        return 0
    end
    return inf.score
end
SL.filterScore = SL.getFilterScore

function SL.getFilterItem(self)
    return self:inserter().filterName
end
SL.filterItem = SL.getFilterItem
SL.filterName = SL.getFilterItem
SL.provItem = SL.getFilterItem

function SL.hasMoved(self)
    if (not self.canMove) then
        return false
    end
    if (not self._lastPos) then
        self._lastPos = self:position()
        return true
    end
    local pos = self:position()
    if (pos.x == self._lastPos.x) and (pos.y == self._lastPos.y) then
        return false
    end
    self._lastPos = pos
    return true
end

function SL.providers(self)
    local chests = self:force():provsInCat(self.category)
    if (gSets.rangeIsInfinite()) then
        return chests
    end
    local res = {}
    for i = 1, #chests do
        local inf = chests[i]
        local chest = inf.chest
        local itemName = inf.item
        if (chest:isInRange(self)) then
            Array.insert(res, inf)
        end
    end
    return res
end

function SL.providersQ(self)
    local chests = self:force().chests
    local q = idQ.new(TC, true)
    for chest in chests:iter() do
        if (chest:isInRange(self)) and (chest:isProvidingCat(self.category)) then
            q:push(chest)
        end
    end
    return q
end

function SL.bestProvider(self)
    local chests = self:force().chests
    local best = {chest = nil, score = 0}
    for chest in chests:iter() do
        if (chest:isInRange(self)) then
            local items = chest:catItems(self.category)
            for i = 1, #items do
                local itemName = items[i]
                local inf = itemInfo(itemName)
                if inf.score > best.score then
                    best.chest = chest
                    best.score = inf.score
                end
            end
        end
    end
    return best.chest
end

function SL.doProvide(self)
    if (not self.isProvided) or (self._inserter.lastTick + gSets.slotProvideMinTicks() > gSets.tick()) then
        return
    end
    self._inserter.lastTick = gSets.tick()
    local chest = self:provider()
    if (not gSets.rangeIsInfinite()) and (self.canMove) then
        if (self:hasMoved()) then
            self:force().orphans:push(self)
            cInform("slot has moved!")
            if (chest) and (not self:isInRange(chest)) then
                self:setProv()
                return false
            end
        end
    end
    if (not chest) then
        -- self:force().orphans:push(self)
        return false
    end
    local filterItem = self:filterItem()
    local filterItemInf = itemInfo(filterItem)
    if not filterItemInf then
        return false
    end
    local slotStack = self:getItemStack()
    if (slotStack.count > 0) and (slotStack.name ~= filterItem) then
        return
    end
    local amtToFull = filterItemInf.fillLimit - slotStack.count
    if (amtToFull > 0) then
        -- inform("need to fill")
        local fillStack = {name = filterItem, count = amtToFull}
        local amtRemoved = chest:remove(fillStack)
        if (amtRemoved > 0) then
            -- inform("provide: set_stack")
            fillStack.count = slotStack.count + amtRemoved
            self:setItemStack(fillStack)
        end
    end
end

function SL.needReturn(self, val)
    -- if (val) and (not self._needReturn) then
    local q = self:force().slotsNeedReturn
    if (val) and (not self._needReturn) then
        self._needReturn = val
        q:push(self)
    elseif (val == false) then
        self._needReturn = nil
    elseif (val == nil) then
        return self._needReturn
    end
end

function SL.registerCons(self, chest, item)
    local f = self:force()
    local ins = self:inserter()
    local curID = ins.sourceID
    -- local curProv = TC.getObj(curID)
    if (curID) then
        local pItem = f:provItem(ins.filterName)
        local reg = pItem.ids[curID]
        if (reg) then
            reg[self.id] = nil
        end
    end
    if (not chest) then
        -- f:addOrphan(self)
        f:provCat(self.consumerCat).orphans[self.id] = true
        self.isOrphan = true
    else
        -- f:removeOrphan(self)
        local reg = f:provItem(item).ids[chest.id]
        if (reg) then
            f:provCat(self.consumerCat).orphans[self.id] = nil
            reg[self.id] = true
            self.isOrphan = nil
        end
    end
end

function SL.setSourceID(self, id)
    local chest = TC.getObj(id)
    if (not chest) then
        id = nil
    end
    if (self.isProvided) then
        self._inserter.sourceID = id
    else
        self:inserter():setPickupTarget(TC.getObj(id))
    end
end

function SL.setFilterItem(self, item)
    if (self.isProvided) then
        self._inserter.filterName = item
    else
        self:inserter():setFilter(item)
    end
end

function SL.setProv(self, chestObj, item)
    if (not chestObj) or (not item) then
        self:registerCons()
        self:setSourceID(nil)
        self:setFilterItem(nil)
        return false
    else
        -- local wasOrphan = self.isOrphan
        local stack = self:itemStack()
        local heldStack = self:heldStack()
        local itemInf = itemInfo(item)
        if (stack.count > 0) and (itemInfo(stack.name).rank > itemInf.rank) then
            self:returnItems()
        elseif (heldStack.count > 0) and (itemInfo(heldStack.name).rank > itemInf.rank) then
            cInform("found held stack!")
            self:returnItems()
        else
            cInform("no current items to remove")
        end
        self:registerCons(chestObj, item)
        self:setSourceID(chestObj.id)
        self:setFilterItem(item)
        local itemCount = chestObj:itemAmt(item) - itemInf.fillLimit
        chestObj:itemAmt(item, itemCount)
        return true
    end
end

function SL.provItems(self)
    return self:force():provItems(self.consumerCat)
end

function SL.provItem(self, itemName)
    return self:force():provItem(itemName)
end

function SL.queueAllProvs(self, rush)
    -- local provs = self:providers()
    -- for i = 1, #provs do
    --     local inf = provs[i]
    --     local chest = inf.chest
    --     local itemName = inf.item
    --     local q = chest._addCache[itemName].orphanQ
    --     if (not q) then
    --         inform("no q...")
    --     else
    --         if (rush) then
    --             q:pushleft(self)
    --         else
    --             q:push(self)
    --         end
    --     end
    -- end

    local f = self:force()
    local provCat = f:provCat(self.consumerCat)
    for itemName, provItem in pairs(provCat.items) do
        for id, cons in pairs(provItem.ids) do
            local prov = TC.getObj(id)
            if prov then
                -- provItem.ids[id] = nil
                -- else
                if (self:isInRange(prov)) then
                    local q = prov._addCache[itemName].orphanQ
                    if (not q) then
                        inform("no q...")
                    else
                        if (rush) then
                            q:pushleft(self)
                        else
                            q:push(self)
                        end
                    end
                end
            end
        end
    end
end

function SL.newInserter(self)
    local newIns = HI.new(self)
    return newIns
end

function SL.isValid(self)
    if not self then
        return false
    end
    if (not self.ent) or (not self.ent.valid) then
        return false
    end
    return true
end

function SL.insert(self, stack)
    local curStack = self:itemStack()
    local newAmt = stack.count
    if (curStack.count > 0) then
        if (curStack.name ~= stack.name) then
            return 0
        end
        newAmt = stack.count + curStack.count
    end
    local itemInf = ItemDB.item.get(stack.name)
    local stackSize = itemInf.stackSize
    if (stackSize < newAmt) then
        newAmt = stackSize
    end
    if (newAmt > curStack.count) then
        self:setItemStack({name = stack.name, count = newAmt})
        return newAmt - curStack.count
    else
        return 0
    end
end

function SL.remove(self, stack)
    local curStack = self:itemStack()
    if (curStack.count <= 0) or (curStack.name ~= stack.name) then
        return 0
    end
    local newAmt = stack.count - curStack.count
    -- local itemInf = ItemDB.item.get(stack.name)
    -- local stackSize = itemInf.stackSize
    if (newAmt <= 0) then
        newAmt = 0
    end
    if (newAmt < curStack.count) then
        self:setItemStack({name = stack.name, count = newAmt})
        return curStack.count - newAmt
    end
    return 0
end

function SL.returnItems(self, matchFilter)
    local force = self:force()
    if (force.storageChests:size() <= 0) then
        return
    end
    -- local retCount = 0
    if (self.inserterID) then
        self:inserter():returnHeldStack()
    -- retCount = retCount + insDropAmt
    end
    local curStack = self:itemStack()
    if (curStack.count <= 0) then
        cInform("no items to return")
        return curStack
    end
    cInform("need to return ", curStack.count, " ", curStack.name)
    local filterName = self:filterItem()
    if (matchFilter) and (curStack.name == filterName) then
        cInform("matchfilter exit")
        return curStack
    end
    -- local slot = self:slot()
    local curProv = self:provider()
    if (curProv) then
        local inserted = curProv.inv.insert(curStack)
        curStack.count = curStack.count - inserted
        -- retCount = retCount + inserted
        if (curStack.count <= 0) then
            cInform("stack returned to provider: ", curStack.name, " ", inserted)
            -- slot.clear()
            self:setStack()
            return curStack
        end
        cInform("some items returned. Setting stack count to ", curStack.count)
    -- self:setStack(curStack)
    end
    local remains = force:sendToStorage(curStack)
    self:setStack(remains)
    return remains
end

function SL.returnEntItems(ent)
    for id, slotObj in pairs(SL.allSlots()) do
        if (slotObj.ent == ent) then
            slotObj:returnItems()
        end
    end
end

function SL.getSlotItemStack(slot)
    local stack = SL.emptyStack()
    if (not isValid(slot)) or (not slot.valid_for_read) then
        return stack
    end
    stack.name = slot.name
    stack.count = slot.count
    return stack
end

function SL.isValidSlot(inv, ind)
    if not isValid(inv) then
        return false
    end
    local maxSlot = #inv
    if (maxSlot < ind) then
        return false
    end
    local slot = inv[ind]
    if not isValid(slot) then
        return false
    end
    return true
end

function SL.isBurner(ent, inv)
    if (not ent.burner) or (not ent.burner.inventory) then
        return false
    end
    if (ent.burner.inventory == inv) then
        return true
    end
    return false
end

function SL.getInvInd(ent, inv)
    for name, ind in pairs(defines.inventory) do
        local newInv = ent.get_inventory(ind)
        if (newInv == inv) then
            return ind
        end
    end
    return nil
end

function SL.dbInsert(slotObj)
    return DB.insert(SL.dbName, slotObj)
end

function SL.getType(slot)
    local _, type = SL.getSlotCat(slot)
    return type
end

function SL.entCanMove(ent)
    if (ent.speed ~= nil) then
        return true
    end
    return false
end

function SL.getObj(id)
    return DB.getObj(SL.dbName, id)
end

function SL.getSlotsFromEnt(ent, queue)
    local slots = DB.getEntries(SL.dbName)
    local result = {}
    if (queue) then
        result = idQ.new(SL)
    end
    for id, slotObj in pairs(slots) do
        if (slotObj) and (slotObj.ent == ent) then
            if queue then
                result:push(slotObj)
            else
                result[#result + 1] = slotObj
            end
        end
    end
    return result
end

function SL.getItemStack(self)
    local slot = self:slot()
    -- if (self.slot ~= nil) then slot = self.slot end
    -- local emptyStack = {name = nil, count = 0}
    if (not slot.valid_for_read) then
        return SL.emptyStack()
    else
        return {name = slot.name, count = slot.count}
    end
end
SL.itemStack = SL.getItemStack

function SL.setItemStack(self, stack)
    local slot = self:slot()
    if (not stack) or (not stack.name) or (stack.count <= 0) then
        slot.clear()
        return true
    end
    local curStack = self:itemStack()
    if (curStack.count > 0) and (curStack.name ~= stack.name) then
        cInform("warning: slot already contains different item. Current items will be overwritten")
    end
    if (slot.can_set_stack(stack)) then
        slot.set_stack(stack)
        return true
    end
    return false
end
SL.setStack = SL.setItemStack

function SL.getSlotCat(slot)
    local canInsert = slot.can_set_stack
    if (canInsert({name = "iron-plate", count = 1})) then
        return nil
    end
    for name, info in pairs(ItemDB.items()) do
        if (canInsert({name = name, count = 1})) then
            return info.category, info.type
        end
    end
    return nil
end

function SL.renders(self, player)
    local rend = self.render
    if (not rend[player.index]) then
        rend[player.index] = {}
    end
    return rend[player.index]
end

function SL.highlight(self, player, color)
    if not color then
        -- color = {r = 0.5, g = 0.125, b = 0.03, a = 0.2}
        color = util.colors.blue
    end
    local rend = self:renders(player)
    local cur = rend.highlight
    if (cur) then
        rendering.destroy(cur)
    end
    rend.highlight =
        rendering.draw_circle(
        {
            color = color,
            radius = 0.75,
            width = 1.0,
            filled = true,
            target = self.ent,
            surface = self:surface().name,
            players = {player.index},
            draw_on_ground = false
        }
    )
end

function SL.drawLineToProvider(self, player)
    local prov = self:provider()
    if (not prov) then
        return
    end
    local rend = self:renders(player)
    local curLine = rend.lineToProv
    if (curLine) then
        rendering.destroy(curLine)
    end
    rend.lineToProv =
        rendering.draw_line(
        {
            -- color = {r = 0.5, g = 0.125, b = 0.03, a = 0.1},
            color = util.colors.purple,
            width = 1.0,
            from = self.ent,
            to = prov.ent,
            surface = self:surface().name,
            players = {player.index},
            draw_on_ground = false
        }
    )
end

function SL.clearRender(self, player)
    for k, id in pairs(self.render[player.index]) do
        rendering.destroy(id)
    end
    self.render[player.index] = nil
end

return SL
