local names = require("prototypes.names")
local util = require("prototypes.util")

local recipes = {}
local startEnabled = settings.startup["ammo_loader_bypass_research"].value
local filterInserterName = "filter-inserter"
if (data.raw["item"]["yellow-filter-inserter"]) then
    filterInserterName = "yellow-filter-inserter"
end
recipes.ammoLoader =
    util.modifiedEnt(
    data.raw["recipe"]["iron-chest"],
    {
        type = "recipe",
        name = names.chests.loader,
        enabled = startEnabled,
        energy_required = 2,
        result = names.chests.loader
    },
    {
        ingredients = {
            {"electronic-circuit", 20},
            {"iron-chest", 2},
            {filterInserterName, 3}
        }
    }
)
recipes.requester1 =
    util.modifiedEnt(
    data.raw["recipe"]["logistic-chest-requester"],
    {
        type = "recipe",
        name = names.chests.requester,
        enabled = startEnabled,
        energy_required = 2,
        result = names.chests.requester
    },
    {
        ingredients = {
            {"logistic-chest-requester", 2},
            {filterInserterName, 5}
        }
    }
)
recipes.storage =
    util.modifiedEnt(
    data.raw["recipe"]["logistic-chest-storage"],
    {
        type = "recipe",
        name = names.chests.storage,
        enabled = startEnabled,
        result = names.chests.storage
    },
    {
        ingredients = {
            {"logistic-chest-storage", 2},
            {filterInserterName, 8}
        }
    }
)
recipes.passiveProvider =
    util.modifiedEnt(
    data.raw["recipe"]["logistic-chest-passive-provider"],
    {
        type = "recipe",
        name = names.chests.passiveProvider,
        enabled = startEnabled,
        energy_required = 2,
        result = names.chests.passiveProvider
    },
    {
        ingredients = {
            {"logistic-chest-passive-provider", 2},
            {filterInserterName, 5}
        }
    }
)

for k, v in pairs(recipes) do
    data:extend {v}
end
