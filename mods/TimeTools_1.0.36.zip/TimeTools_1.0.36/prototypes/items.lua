data:extend(
{
	----------------------------------------------------------------------------------
	{
		type = "item",
		name = "clock-combinator",
		icon = "__TimeTools__/graphics/clock-combinator-icon.png",
		icon_size = 32,
		flags = { },
		subgroup = "circuit-network",
		place_result="clock-combinator",
		order = "b[combinators]-d[clock-combinator]",
		stack_size= 50,
	},

}
)

