Repository for the Factorio Big Brother mod.

Description
===========

Mod compatibility
=================

Contributing
============
Contributions are welcome.
