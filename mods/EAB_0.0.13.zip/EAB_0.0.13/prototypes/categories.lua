data:extend(
  {
    {
      type = "item-subgroup",
      name = "rich-productivity-modules",
      group = "bobmodules",
      order = "f-10"
    }
  }
)
