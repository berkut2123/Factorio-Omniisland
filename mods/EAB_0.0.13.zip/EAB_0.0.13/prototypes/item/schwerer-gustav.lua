data:extend(
  {
    {
      type = "item-with-entity-data",
      name = "schwerer-gustav",
      icon = "__base__/graphics/icons/artillery-wagon.png",
      icon_size = 32,
      subgroup = "transport",
      order = "a[train-system]-i[artillery-wagon]",
      place_result = "schwerer-gustav",
      stack_size = 5
    }
  }
)
