data:extend{
    {
        type = "int-setting",
        name = "aai-signal-transmission-tick",
        setting_type = "runtime-global",
        default_value = 1,
        minimum_value = 1,
        maximum_value = 600,
    }
}
