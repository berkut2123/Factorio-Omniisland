local globals = {MAX_CONFIG_SIZE = 24, MAX_STORAGE_SIZE = 12}
return globals
