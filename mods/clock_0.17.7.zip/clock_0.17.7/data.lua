data:extend(
{
    {
        type = "font", 
        name = "digital-clock",
        from = "digital-clock",
        size = 20
    }
})
